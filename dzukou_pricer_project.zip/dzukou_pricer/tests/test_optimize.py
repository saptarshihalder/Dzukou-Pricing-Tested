from dzukou_pricer.app.optimize import optimise_price


def test_optimise_price_basic():
    # Simple scenario: COGS=10, elasticity=-1.2, competitor min=15, current=18
    price, units, profit, profit_uplift, demand_uplift = optimise_price(
        cogs=10.0,
        elasticity=-1.2,
        current_price=18.0,
        competitor_min_price=15.0,
        margin_floor=0.1,
        baseline_units=100.0,
        price_step=0.5,
    )
    # Price should be >= 11 (COGS * 1.1)
    assert price >= 11.0
    # Price should not exceed competitor_min*1.2
    assert price <= 18.0
    # Profit uplift should be a number (could be positive or negative)
    assert profit_uplift is not None