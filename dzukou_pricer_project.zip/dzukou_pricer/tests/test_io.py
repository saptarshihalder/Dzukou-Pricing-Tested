import pandas as pd

from dzukou_pricer.app.io import read_catalog


def test_read_catalog_basic(tmp_path):
    # Create a temporary CSV with various column names
    csv_path = tmp_path / "catalog.csv"
    data = {
        "ID": ["A1", "B2"],
        "Name": ["Eco Bottle", "Bamboo Straw"],
        "Brand_Name": ["Green", "Eco"],
        "Cost": [5.0, 2.0],
        "Price": [10.0, 4.0],
        "Pack": [1, 4],
    }
    df = pd.DataFrame(data)
    df.to_csv(csv_path, index=False)
    items = read_catalog(str(csv_path))
    assert len(items) == 2
    assert items[0].item_id == "A1"
    assert items[0].item_name == "Eco Bottle"
    assert items[0].brand == "Green"
    assert items[0].cogs == 5.0
    assert items[0].current_price == 10.0
    assert items[0].pack_count == 1