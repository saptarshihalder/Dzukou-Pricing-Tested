from dzukou_pricer.app.fx import convert


def test_currency_conversion():
    # Basic conversion using fallback rates should be consistent
    amount = 1.0
    usd_from_eur = convert(amount, "EUR", "USD")
    eur_from_usd = convert(amount, "USD", "EUR")
    assert usd_from_eur > 0
    assert eur_from_usd > 0
    # Converting back should be approximately consistent within 10 %
    round_trip = convert(usd_from_eur, "USD", "EUR")
    assert abs(round_trip - amount) / amount < 0.1