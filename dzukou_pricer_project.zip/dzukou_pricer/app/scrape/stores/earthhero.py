"""
Scraper for EarthHero.
"""
from __future__ import annotations

from .generic import GenericStoreScraper


class EarthHeroScraper(GenericStoreScraper):
    name = "EarthHero"
    domain = "earthhero.com"
    base_url = "https://earthhero.com"
    search_path = "/search?q={query}"
    rate_limit_per_sec = 0.5