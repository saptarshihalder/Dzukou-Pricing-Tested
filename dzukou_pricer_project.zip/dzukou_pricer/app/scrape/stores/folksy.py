"""
Scraper for Folksy.
"""
from __future__ import annotations

from .generic import GenericStoreScraper


class FolksyScraper(GenericStoreScraper):
    name = "Folksy"
    domain = "folksy.com"
    base_url = "https://folksy.com"
    search_path = "/search?q={query}"
    rate_limit_per_sec = 0.5