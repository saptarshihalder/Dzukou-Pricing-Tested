"""
Scraper for Package Free Shop.
"""
from __future__ import annotations

from .generic import GenericStoreScraper


class PackageFreeScraper(GenericStoreScraper):
    name = "Package Free Shop"
    domain = "packagefreeshop.com"
    base_url = "https://packagefreeshop.com"
    search_path = "/search?q={query}"
    rate_limit_per_sec = 0.5