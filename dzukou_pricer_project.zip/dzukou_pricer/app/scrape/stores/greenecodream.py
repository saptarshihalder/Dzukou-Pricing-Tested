"""
Scraper for Green Eco Dream.
"""
from __future__ import annotations

from .generic import GenericStoreScraper


class GreenEcoDreamScraper(GenericStoreScraper):
    name = "Green Eco Dream"
    domain = "greenecodream.com"
    base_url = "https://greenecodream.com"
    search_path = "/search?q={query}"
    rate_limit_per_sec = 0.5