"""
Scraper for Ten Thousand Villages.
"""
from __future__ import annotations

from .generic import GenericStoreScraper


class TenThousandVillagesScraper(GenericStoreScraper):
    name = "Ten Thousand Villages"
    domain = "tenthousandvillages.com"
    base_url = "https://tenthousandvillages.com"
    search_path = "/search?q={query}"
    rate_limit_per_sec = 0.5