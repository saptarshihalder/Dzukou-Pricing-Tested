"""
Generic store scraper implementation.

This module defines a ``GenericStoreScraper`` that can scrape
e‑commerce sites with a simple search endpoint returning HTML.  It
builds search URLs based on a template and uses heuristics to extract
product titles and prices.  If the page appears to be a Shopify
storefront, it delegates to the Shopify parser.
"""
from __future__ import annotations

import asyncio
import html
import re
from typing import List

from bs4 import BeautifulSoup

from ..base import BaseScraper
from ..shopify import detect_shopify, extract_products_from_html
from ...ingest import NormalisedItem
from ...types import Candidate


PRICE_RE = re.compile(r"([\$\£\€])\s*([0-9]+\.?[0-9]*)")


class GenericStoreScraper(BaseScraper):
    """A scraper for stores that support a basic search page."""

    async def search(self, item: NormalisedItem) -> List[Candidate]:
        query = "+".join(re.split(r"\s+", item.item.item_name.strip()))
        url = f"{self.base_url}{self.search_path.format(query=query)}"
        html_text = await self._fetch(url)
        if not html_text:
            return []
        # Check for Shopify and delegate
        if detect_shopify(html_text):
            return extract_products_from_html(html_text, self.name, self.base_url)
        soup = BeautifulSoup(html_text, "lxml")
        candidates: List[Candidate] = []
        # Heuristic: find all anchor tags within product listing containers
        # Look for price patterns near product titles
        for a in soup.find_all("a", href=True):
            title = a.get_text(strip=True)
            href = a["href"]
            # Skip trivial links
            if not title or not href:
                continue
            price = None
            currency = None
            # Look for price sibling
            text = a.parent.get_text(" ", strip=True) if a.parent else title
            m = PRICE_RE.search(text)
            if m:
                currency_symbol, price_str = m.groups()
                try:
                    price = float(price_str)
                except Exception:
                    price = None
                currency = {"$": "USD", "£": "GBP", "€": "EUR"}.get(currency_symbol)
            candidates.append(
                Candidate(
                    store=self.name,
                    url=href if href.startswith("http") else f"{self.base_url.rstrip('/')}{href}",
                    title=title,
                    brand=None,
                    size=None,
                    shelf_price=price,
                    compare_at_price=None,
                    shipping_cost=None,
                    vat_included=None,
                    currency=currency,
                    stock=None,
                    rating_count=None,
                )
            )
            # Limit to 20 results
            if len(candidates) >= 20:
                break
        return candidates


__all__ = ["GenericStoreScraper"]