"""
Scraper for DoneGood.
"""
from __future__ import annotations

from .generic import GenericStoreScraper


class DoneGoodScraper(GenericStoreScraper):
    name = "DoneGood"
    domain = "donegood.co"
    base_url = "https://donegood.co"
    search_path = "/search?type=product&q={query}"
    rate_limit_per_sec = 0.5