"""
Scraper for GOODEE.
"""
from __future__ import annotations

from .generic import GenericStoreScraper


class GoodeeScraper(GenericStoreScraper):
    name = "GOODEE"
    domain = "goodeeworld.com"
    base_url = "https://goodeeworld.com"
    search_path = "/search?q={query}"
    rate_limit_per_sec = 0.5