"""
Scraper for Made Trade.
"""
from __future__ import annotations

from .generic import GenericStoreScraper


class MadeTradeScraper(GenericStoreScraper):
    name = "Made Trade"
    domain = "madetrade.com"
    base_url = "https://madetrade.com"
    search_path = "/search?q={query}"
    rate_limit_per_sec = 0.5