"""
Scraper for NOVICA.
"""
from __future__ import annotations

from .generic import GenericStoreScraper


class NovicaScraper(GenericStoreScraper):
    name = "NOVICA"
    domain = "novica.com"
    base_url = "https://novica.com"
    search_path = "/search?q={query}"
    rate_limit_per_sec = 0.5