"""
Scraper for Wild Minimalist.
"""
from __future__ import annotations

from .generic import GenericStoreScraper


class WildMinimalistScraper(GenericStoreScraper):
    name = "Wild Minimalist"
    domain = "wildminimalist.com"
    base_url = "https://wildminimalist.com"
    search_path = "/search?q={query}"
    rate_limit_per_sec = 0.5