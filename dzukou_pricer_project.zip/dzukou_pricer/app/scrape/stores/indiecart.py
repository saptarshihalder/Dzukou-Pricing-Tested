"""
Scraper for IndieCart.
"""
from __future__ import annotations

from .generic import GenericStoreScraper


class IndieCartScraper(GenericStoreScraper):
    name = "IndieCart"
    domain = "indiecart.com"
    base_url = "https://indiecart.com"
    search_path = "/search?q={query}"
    rate_limit_per_sec = 0.5