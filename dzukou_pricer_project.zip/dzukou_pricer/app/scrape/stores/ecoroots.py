"""
Scraper for EcoRoots.
"""
from __future__ import annotations

from .generic import GenericStoreScraper


class EcoRootsScraper(GenericStoreScraper):
    name = "EcoRoots"
    domain = "ecoroots.us"
    base_url = "https://ecoroots.us"
    search_path = "/search?q={query}"
    rate_limit_per_sec = 0.5