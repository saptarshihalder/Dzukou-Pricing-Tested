"""
Scraper for The Citizenry.
"""
from __future__ import annotations

from .generic import GenericStoreScraper


class TheCitizenryScraper(GenericStoreScraper):
    name = "The Citizenry"
    domain = "the-citizenry.com"
    base_url = "https://the-citizenry.com"
    search_path = "/search?q={query}"
    rate_limit_per_sec = 0.5