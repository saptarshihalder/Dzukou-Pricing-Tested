"""
Scraper for The Little Market.
"""
from __future__ import annotations

from .generic import GenericStoreScraper


class TheLittleMarketScraper(GenericStoreScraper):
    name = "The Little Market"
    domain = "thelittlemarket.com"
    base_url = "https://thelittlemarket.com"
    search_path = "/search?type=product&q={query}"
    rate_limit_per_sec = 0.5