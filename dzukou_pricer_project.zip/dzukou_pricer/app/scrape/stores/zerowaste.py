"""
Scraper for Zero Waste Store.
"""
from __future__ import annotations

from .generic import GenericStoreScraper


class ZeroWasteScraper(GenericStoreScraper):
    name = "Zero Waste Store"
    domain = "zerowastestore.com"
    base_url = "https://zerowastestore.com"
    search_path = "/search?q={query}"
    rate_limit_per_sec = 0.5