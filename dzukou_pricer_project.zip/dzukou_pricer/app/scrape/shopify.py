"""
Shopify parsing utilities.

This module contains helper functions to detect Shopify storefronts
based on HTML and extract product information from JSON‑LD or
embedded script tags.  When a store is identified as Shopify, the
generic scraper can leverage this to parse product listings.
"""
from __future__ import annotations

import json
from typing import List

from bs4 import BeautifulSoup

from ..types import Candidate


def detect_shopify(html: str) -> bool:
    """Detect whether a page belongs to a Shopify storefront."""
    return "cdn.shopify.com" in html or "Shopify.theme" in html or "window.Shopify" in html


def extract_products_from_html(html: str, store_name: str, base_url: str) -> List[Candidate]:
    """Extract product data from a Shopify storefront page.

    This looks for JSON‑LD scripts containing Product schema and
    returns a list of Candidates.
    """
    soup = BeautifulSoup(html, "lxml")
    candidates: List[Candidate] = []
    scripts = soup.find_all("script", type="application/ld+json")
    for script in scripts:
        try:
            data = json.loads(script.string or "")
        except Exception:
            continue
        # Some pages have a list of items under @graph
        items = []
        if isinstance(data, list):
            items = data
        elif isinstance(data, dict):
            if "@graph" in data and isinstance(data["@graph"], list):
                items = data["@graph"]
            else:
                items = [data]
        for item in items:
            if not isinstance(item, dict):
                continue
            if item.get("@type") != "Product":
                continue
            name = item.get("name") or ""
            brand = None
            if isinstance(item.get("brand"), dict):
                brand = item["brand"].get("name")
            offers = item.get("offers")
            price = None
            currency = None
            if isinstance(offers, dict):
                price = offers.get("price")
                currency = offers.get("priceCurrency")
            elif isinstance(offers, list) and offers:
                o = offers[0]
                price = o.get("price")
                currency = o.get("priceCurrency")
            # Build URL
            url = item.get("url")
            if url and url.startswith("/"):
                url = base_url.rstrip("/") + url
            if price is not None:
                try:
                    price_float = float(price)
                except Exception:
                    price_float = None
            else:
                price_float = None
            candidates.append(
                Candidate(
                    store=store_name,
                    url=url or "",
                    title=name,
                    brand=brand,
                    size=None,
                    shelf_price=price_float,
                    compare_at_price=None,
                    shipping_cost=None,
                    vat_included=None,
                    currency=currency,
                    stock=None,
                    rating_count=None,
                )
            )
    return candidates


__all__ = ["detect_shopify", "extract_products_from_html"]